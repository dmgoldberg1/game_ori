timer_npc = [True]
